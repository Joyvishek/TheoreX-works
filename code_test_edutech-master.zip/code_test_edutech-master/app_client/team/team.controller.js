(function() {
  
  angular
    .module('meanApp')
    .controller('teamCtrl', teamCtrl);
  teamCtrl.$inject = ['$scope'];
    function teamCtrl ($scope) {
      console.log('Team controller is running');

    }

})();

