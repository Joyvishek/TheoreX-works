(function() {
  
  angular
    .module('meanApp')
    .controller('eventCtrl', eventCtrl);
  eventCtrl.$inject = ['$scope'];
    function eventCtrl ($scope) {
      console.log('Event controller is running');

    }

})();

