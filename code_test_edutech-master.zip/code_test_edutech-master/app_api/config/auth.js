// config/auth.js

// expose our config directly to our application using module.exports
module.exports = {

    'facebookAuth' : {
        'clientID'      : '1786741998228923', // your App ID
        'clientSecret'  : 'c7f02a2c80484968e9d682441361e4b7', // your App Secret
        'callbackURL'   : 'http://theorexedutech.com/api/login_external/facebook/callback'
    },

    'twitterAuth' : {
        'consumerKey'       : '9D7AKQflGwghKaCYpi5Gpwy5m',
        'consumerSecret'    : 'pZo8JMOzrXzI8apVIFj8v9tIUXT25un4FwAs6ILDZmPuaTZvkU',
        'callbackURL'       : 'http://theorexedutech.com/api/login_external/twitter/callback'
    },

    'googleAuth' : {
        'clientID'      : '351684979720-masb6r4fokcqk13eo4qlko24qr8sbvlu.apps.googleusercontent.com',
        'clientSecret'  : 't1Su7mnM64t69TxruKskp7fQ',
        'callbackURL'   : 'http://theorexedutech.com/api/login_external/callback'
    },

    'linkedinAuth' : {
        'consumerKey'       : '81vs6idram25fn',
        'consumerSecret'    : 'ZxQWFYylJ6G22O0P',
        'callbackURL'       : 'http://theorexedutech.com/api/login_external/linkedin/callback'
    },
};
